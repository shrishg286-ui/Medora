const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { z } = require('zod');
const prisma = require('../db');
const { auth } = require('../middleware/auth');
const { publicUser } = require('../utils/sanitize');
const router = express.Router();

const registerSchema = z.object({
  name: z.string().min(2).max(100),
  email: z.string().email().max(200),
  phone: z.string().min(7).max(20).optional(),
  password: z.string().min(8).max(100),
  role: z.enum(['PATIENT','DOCTOR','COMPOUNDER','NURSE','PHARMACY']).default('PATIENT'),
  qualification: z.string().max(200).optional(),
  specialization: z.string().max(200).optional(),
  licenseNumber: z.string().max(100).optional()
});

function tokenFor(user) {
  return jwt.sign({ sub: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });
}

router.post('/register', async (req, res, next) => {
  try {
    const data = registerSchema.parse(req.body);
    const exists = await prisma.user.findFirst({ where: { OR: [{ email: data.email.toLowerCase() }, ...(data.phone ? [{ phone: data.phone }] : [])] } });
    if (exists) return res.status(409).json({ error: 'Email or phone already registered' });
    const passwordHash = await bcrypt.hash(data.password, 12);
    const user = await prisma.user.create({
      data: {
        name: data.name,
        email: data.email.toLowerCase(),
        phone: data.phone,
        passwordHash,
        role: data.role,
        providerProfile: data.role !== 'PATIENT' ? { create: { qualification: data.qualification, specialization: data.specialization, licenseNumber: data.licenseNumber } } : undefined
      }
    });
    res.status(201).json({ user: publicUser(user), token: tokenFor(user), message: data.role === 'PATIENT' ? 'Registration successful' : 'Registration submitted for provider verification' });
  } catch (e) { next(e); }
});

router.post('/login', async (req, res, next) => {
  try {
    const data = z.object({ email: z.string().email(), password: z.string().min(1) }).parse(req.body);
    const user = await prisma.user.findUnique({ where: { email: data.email.toLowerCase() } });
    if (!user || !(await bcrypt.compare(data.password, user.passwordHash))) return res.status(401).json({ error: 'Invalid email or password' });
    res.json({ user: publicUser(user), token: tokenFor(user) });
  } catch (e) { next(e); }
});

router.get('/me', auth, (req, res) => res.json({ user: publicUser(req.user) }));
module.exports = router;
