const express = require('express');
const { z } = require('zod');
const prisma = require('../db');
const { auth, requireRoles } = require('../middleware/auth');
const router = express.Router();
router.use(auth);

router.post('/', requireRoles('PATIENT'), async (req, res, next) => {
  try {
    const data = z.object({ deliveryAddress: z.string().min(5), prescriptionReportId: z.string().optional(), items: z.array(z.object({ medicineId: z.string(), quantity: z.number().int().positive() })).min(1) }).parse(req.body);
    const ids = data.items.map(i => i.medicineId);
    const meds = await prisma.medicine.findMany({ where: { id: { in: ids }, active: true } });
    if (meds.length !== ids.length) return res.status(400).json({ error: 'One or more medicines are unavailable' });
    const byId = new Map(meds.map(m => [m.id, m]));
    for (const item of data.items) if (byId.get(item.medicineId).stock < item.quantity) return res.status(400).json({ error: `Insufficient stock for ${byId.get(item.medicineId).name}` });
    const needsRx = data.items.some(i => byId.get(i.medicineId).requiresRx);
    if (needsRx && !data.prescriptionReportId) return res.status(400).json({ error: 'Prescription report is required for one or more items' });
    if (data.prescriptionReportId) {
      const report = await prisma.report.findFirst({ where: { id: data.prescriptionReportId, patientId: req.user.id } });
      if (!report) return res.status(400).json({ error: 'Invalid prescription report' });
    }
    const totalAmount = data.items.reduce((sum, i) => sum + byId.get(i.medicineId).price * i.quantity, 0);
    const order = await prisma.$transaction(async tx => {
      const created = await tx.order.create({ data: { patientId: req.user.id, deliveryAddress: data.deliveryAddress, totalAmount, prescriptionReportId: data.prescriptionReportId, items: { create: data.items.map(i => ({ medicineId: i.medicineId, quantity: i.quantity, unitPrice: byId.get(i.medicineId).price })) } }, include: { items: { include: { medicine: true } } } });
      for (const item of data.items) await tx.medicine.update({ where: { id: item.medicineId }, data: { stock: { decrement: item.quantity } } });
      return created;
    });
    res.status(201).json({ order });
  } catch (e) { next(e); }
});

router.get('/mine', async (req, res, next) => {
  try { res.json({ orders: await prisma.order.findMany({ where: { patientId: req.user.id }, include: { items: { include: { medicine: true } }, prescription: true }, orderBy: { createdAt: 'desc' } }) }); }
  catch (e) { next(e); }
});

router.patch('/:id/status', requireRoles('PHARMACY','ADMIN'), async (req, res, next) => {
  try { const { status } = z.object({ status: z.enum(['CONFIRMED','PACKED','OUT_FOR_DELIVERY','DELIVERED','CANCELLED']) }).parse(req.body); const order = await prisma.order.update({ where: { id: req.params.id }, data: { status } }); res.json({ order }); }
  catch (e) { next(e); }
});
module.exports = router;
